# Copyright (c) Facebook, Inc. and its affiliates.
from . import (
    register_iSAID,
    register_DLRSD,
    register_Potsdam,
    register_Vaihingen,
)
